package com.zybooks.myapplicationtest;

import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.provider.Telephony;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;

//Activity class for SMS Notifications. Sadly it is not yet functional.
public class SMSNotificationActivity extends AppCompatActivity {

        //declare button variables
        private final int RECIEVE_SMS_PERMISSION_CODE = 1;
        Button btnBack1;
        Button button2;
        Button button4;

        //onCreate for button use and lay out declaration
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.sms_notification_activity);
            button2 = findViewById(R.id.button2);
            btnBack1 = findViewById(R.id.btnBack1);
            button4 = findViewById(R.id.button4);


            //grant permission button and toast message
            button2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    seekPermission(v);
                    Toast.makeText(SMSNotificationActivity.this, "Permission Granted", Toast.LENGTH_SHORT).show();
                }
            });

            //deny permission button and toast message
            button4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(SMSNotificationActivity.this, "Permission Denied", Toast.LENGTH_SHORT).show();
                }
            });


            //this code from here on out was from a combination of tutorials and online examples from git
            //could not make this work with the time remaining. 
            if (ContextCompat.checkSelfPermission(SMSNotificationActivity.this, Manifest.permission.SEND_SMS) ==
                    PackageManager.PERMISSION_GRANTED) {
                    Intent intent = new Intent(SMSNotificationActivity.this, MainActivity.class);
                    startActivity(intent);
            }

            btnBack1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(SMSNotificationActivity.this, MainActivity.class);
                    startActivity(intent);
                }
            });
        }

        public void seekPermission(View view) {
            if (ContextCompat.checkSelfPermission(
                    SMSNotificationActivity.this, Manifest.permission.SEND_SMS) ==
                    PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(SMSNotificationActivity.this, "Permission already granted", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(SMSNotificationActivity.this, MainActivity.class);
                startActivity(intent);
            } else{

                if (ActivityCompat.shouldShowRequestPermissionRationale(SMSNotificationActivity.this, Manifest.permission.SEND_SMS)) {

                    new AlertDialog.Builder(this)
                            .setTitle("Permission required")
                            .setMessage("This permission is required so that you may recieve automated system notifications")
                            .setPositiveButton("GRANT", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    ActivityCompat.requestPermissions(SMSNotificationActivity.this, new String[]{Manifest.permission.SEND_SMS}, RECIEVE_SMS_PERMISSION_CODE);
                                }
                            })
                            .setNegativeButton("DENY", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            })
                            .create().show();
                } else {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, RECIEVE_SMS_PERMISSION_CODE);

                }
            }
        }

        @Override
        public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            if (requestCode == RECIEVE_SMS_PERMISSION_CODE) {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
                }
            }
            Intent intent = new Intent(SMSNotificationActivity.this, MainActivity.class);
            startActivity(intent);
        }
}
//
//Citations
//
//Build software better, together. GitHub. (n.d.). Retrieved February 19, 2022, from https://github.com/search?q=cs%2B360%2Bproject%2B3
