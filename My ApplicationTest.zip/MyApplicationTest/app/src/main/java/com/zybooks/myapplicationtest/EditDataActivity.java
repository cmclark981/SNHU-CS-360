package com.zybooks.myapplicationtest;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;
import android.os.Bundle;

//public class for editing list data
public class EditDataActivity extends AppCompatActivity {

    private static final String TAG = "EditDataActivity";

    //declare variable and DB
    private Button btnSave,btnDelete, btnBack;
    private EditText editable_item;

    DatabaseHelper mDatabaseHelper;

    private String selectedName;
    private int selectedID;

    //onCreate for buttons and list view onClick
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_data_layout);
        btnSave = findViewById(R.id.btnSave);
        btnDelete = findViewById(R.id.btnDelete);
        editable_item = findViewById(R.id.editable_item);
        btnBack = findViewById(R.id.btnBack);
        mDatabaseHelper = new DatabaseHelper(this);

        //get the intent extra from the ListDataActivity
        Intent receivedIntent = getIntent();

        //now get the itemID we passed as an extra
        selectedID = receivedIntent.getIntExtra("id",-1); //NOTE: -1 is just the default value

        //now get the name we passed as an extra
        selectedName = receivedIntent.getStringExtra("name");

        //set the text to show the current selected name
        editable_item.setText(selectedName);

        //Save button onclick method
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String item = editable_item.getText().toString();
                if(!item.equals("")){
                    mDatabaseHelper.updateName(item,selectedID,selectedName);
                }else{
                    toastMessage("You must enter a name");
                }
            }
        });

        //Delete button onclick method
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDatabaseHelper.deleteName(selectedID,selectedName);
                editable_item.setText("");
                toastMessage("removed from database");
            }
        });

        //Back button method to return to main page
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EditDataActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    //Custom toast message method.
    private void toastMessage(String message){
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }
}
//
//Citations
//
//Editing and deleting data from an sqlite ... - youtube. (n.d.). Retrieved February 19, 2022, from https://www.youtube.com/watch?v=nY2bYJyGty8
//
//Save data into sqlite database [beginner ... - youtube.com. (n.d.). Retrieved February 19, 2022, from https://www.youtube.com/watch?v=aQAIMY-HzL8?vq=small
//
//CodingWithMitch. (n.d.). SQLite for beginners 2019. CodingWithMitch.com. Retrieved February 19, 2022, from https://codingwithmitch.com/courses/sqlite-room-persistence-android/
