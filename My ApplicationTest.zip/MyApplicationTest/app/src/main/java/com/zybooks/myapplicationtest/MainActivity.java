package com.zybooks.myapplicationtest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

//public class for main page activity after log in
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    //declare variables and DB
    DatabaseHelper mDatabaseHelper;
    private Button btnAdd, btnViewData, btnSMS;
    private EditText editText;

    //onCreate for main page and buttons
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = findViewById(R.id.editText);
        btnAdd = findViewById(R.id.btnAdd);
        btnViewData = findViewById(R.id.btnView);
        btnSMS = findViewById(R.id.btnSMS);
        mDatabaseHelper = new DatabaseHelper(this);

        //Add data button to add to database onclick
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newEntry = editText.getText().toString();
                if (editText.length() != 0) {
                    AddData(newEntry);
                    editText.setText("");
                } else {
                    toastMessage("You must put something in the text field!");
                }

            }
        });

        //View data to see list view of data entries
        btnViewData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListDataActivity.class);
                startActivity(intent);
            }
        });

        //SMS button to go to SMS notifications page
        btnSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, SMSNotificationActivity.class);
                startActivity(intent);
            }
        });

    }

    //AddData method to insert data in DB and send toast message
    public void AddData(String newEntry) {
        boolean insertData = mDatabaseHelper.addData(newEntry);

        if (insertData) {
            toastMessage("Data Successfully Inserted!");
        } else {
            toastMessage("Something went wrong");
        }
    }
     void toastMessage(String message){
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }
}

//Citations
//
//Editing and deleting data from an sqlite ... - youtube. (n.d.). Retrieved February 19, 2022, from https://www.youtube.com/watch?v=nY2bYJyGty8
//
//Save data into sqlite database [beginner ... - youtube.com. (n.d.). Retrieved February 19, 2022, from https://www.youtube.com/watch?v=aQAIMY-HzL8?vq=small
//
//CodingWithMitch. (n.d.). SQLite for beginners 2019. CodingWithMitch.com. Retrieved February 19, 2022, from https://codingwithmitch.com/courses/sqlite-room-persistence-android/