package com.zybooks.cs_360module6_3sensormanager;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    SensorManager sensor;
    TextView data;
    List<Sensor> myList;

    SensorEventListener listener = new SensorEventListener() {
        @SuppressLint("SetTextI18n")
        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            float[] sensor_data = sensorEvent.values;
            data.setText("x: "+sensor_data[0]+"\ny: "+sensor_data[1]+"\nz: "+sensor_data[2]);
        }
        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        data = findViewById(R.id.sensorData);
        sensor = (SensorManager)getSystemService(SENSOR_SERVICE);
        myList = sensor.getSensorList(Sensor.TYPE_ACCELEROMETER);

        if(myList.size()!=0){
            sensor.registerListener(listener, myList.get(0), SensorManager.SENSOR_DELAY_NORMAL);
        }else{
            Toast.makeText(getBaseContext(), "No accelerometer detected", Toast.LENGTH_LONG).show();
        }
    }
    @Override
    protected void onStop() {
        super.onStop();
        if(myList.size()!=0)
            sensor.unregisterListener(listener);
    }
}


//Citations
//
//Sensors overview &nbsp;: &nbsp; android developers. Android Developers. (n.d.).
//Retrieved February 8, 2022, from https://developer.android.com/guide/topics/sensors/sensors_overview
//
//Shithik, A. (n.d.). Create sensor android app using Android Studio. C# Corner.
//Retrieved February 8, 2022, from https://www.c-sharpcorner.com/article/create-sensor-android-app-using-android-studio2/